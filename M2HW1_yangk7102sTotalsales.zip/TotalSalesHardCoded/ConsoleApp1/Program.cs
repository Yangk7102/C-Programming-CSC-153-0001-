﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 2/11/2020
* CSC 153
* kabin yang
* puts values in an array the displays
*/

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            
            
            Double[] numbers = {1245.67, 1189.55, 1098.72, 1456.88, 2109.34, 1987.55, 1872.36 };
            //Double[] numbers = new Double[7];
            foreach (double i in numbers)
            {
                Console.WriteLine("{0} ", i);
            }

            string input;

            input = Console.ReadLine();
        }
    }
}
 