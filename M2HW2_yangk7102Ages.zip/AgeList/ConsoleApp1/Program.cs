﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 2/14/2020
* CSC 153
* kabin Yang
* 
    Ask the user to run the age program or exit the program
    Ask the user how many ages the user want to input
    Display all the ages the user inputed
    Display the average age of the list - 10 bonus points

*/
namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<String> AgeList = new List<String>();
            int number;
            string input;

            Console.WriteLine("Age program---\n----------------\n\n1) Run the program\n\n" +
                "2) exit\n\n...");
            input = Console.ReadLine();

            do
            {



                Console.Write("Enter the amount of ages you want input: ");
                input = Console.ReadLine();

                if (int.TryParse(input, out number))
                {
                    Console.WriteLine("you chose to enter " + number + " amount of ages.");
                }
                else
                {
                    Console.WriteLine("input a number pls.");
                }

                for (int x = 0; x < number; x++)
                {
                    Console.Write("Enter a age: ");
                    input = Console.ReadLine();
                    AgeList.Add(input);
                }

                for (int index = 0; index < AgeList.Count; index++)
                {
                    Console.WriteLine($"Age - {AgeList[index]}");
                }
                Console.ReadLine();
            } while (input == "1");

            Console.WriteLine("bye!");


        }
    }
}
