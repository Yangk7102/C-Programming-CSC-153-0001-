﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WritingStuff
{
    class Prints
    {
        public static double ReturnMenu()
        {
            double retail_Price;
            string input;
            bool loop = true;
            Console.WriteLine("MENU\n---------\n");
            do
            {
                Console.Write("Enter the retail price: ");
                input = Console.ReadLine();
                if (double.TryParse(input, out retail_Price))
                {
                    loop = false;
                }
                else
                {
                    Console.WriteLine("error");
                }
                Console.WriteLine("");
            } while (loop == true);
            return retail_Price;

        }
        public static double ReturnValues()
        {
            double markup;
            string input;
            bool loop = true;

            do
            {

                Console.Write("Enter the markup percent ammount: ");
                input = Console.ReadLine();
                Console.Write("");
                if (double.TryParse(input, out markup))
                {
                    loop = false;
                }
                else
                {
                    Console.WriteLine("error");
                }
            } while (loop == true);
            return markup;
        }
    }
}
