﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 2/17/2020
* CSC 153
* Kabin Yang
* Create an application that lets the user enter an items wholesale cost and its markup percentage. It should then display the item's price. For example,

    If the item's wholesale cost is $5.00 and its markup percentage is 100 percent, then the item's retail price is $10.00.
    If an item's wholesale cost is $5.00 and its markup percentage is 50 percent, then the item's retail price is $7.50.

The program should have a method named CalculateRetail that receives the wholesale cost and the markup percentage as arguments and returns the retail price of the item
*
*/
namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            double retail_Price, markup;
            string input;
            bool loop = true;
            do
            {
                retail_Price = WritingStuff.Prints.ReturnMenu();
                markup = WritingStuff.Prints.ReturnValues();
                loop = false;

            } while (loop == true);

            Console.WriteLine($"\n---------\nThe retail was ${retail_Price} \n-----\nThe markup was %{markup}\n-----");
            //Console.ReadLine();
            double whole_Sale = iduuno.Math.CalculateRetail( retail_Price, markup);

            Console.WriteLine($"The Whole sale value is ${whole_Sale}");

            Console.ReadLine();

        }
        
    }
}
