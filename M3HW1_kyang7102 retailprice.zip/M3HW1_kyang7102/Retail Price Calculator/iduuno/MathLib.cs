﻿using System;

namespace iduuno
{
    public class Math
    {
        public static double CalculateRetail(double retail, double markup)
        {
            double whole_Sale;
            markup = markup * .01;
            whole_Sale = retail * markup;
            return whole_Sale;
        }
    }
}
