﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* Date
* CSC 153
* Your Name
* The variables int the formula are as follows: h is the distance in 
* meters, g is 9.8, and t is the amount of time in seconds that the object has been falling.
Create an application that allows the user to enter the
    amount of time that and object has fallen and then display the distance the
    object fell. The application should have a method 
    named FallingDistance. The FallingDistance method should accept an object's 
    falling time (in seconds) as an argument. The 
    method should return the distance in meters that the object has fallen during that time interval.
*/
namespace ConsoleApp1
{
    class Program
    {     

        static void Main(string[] args)
        {
            //---variables---
            double time;
            //--- specific vars--
            string input;
            bool loop = true;
            do
            {
                Console.Write("Enter the amount of time an object will fall in seconds: ");
                input = Console.ReadLine();
                if (double.TryParse(input, out time))
                {
                    loop = false;
                    double distance = FallingDistance(time);

                    Console.WriteLine($"The object has fallen {distance} meters.");
                    Console.ReadLine();


                }
                else
                {
                    Console.WriteLine("error\n input a number please");
                }
                Console.WriteLine("");
            } while (loop == true);
            loop = true;

        }

        public static double FallingDistance(double time)
        {
            double distance, grav;
            grav = 9.8;

            distance = time * grav;
            return distance;
        }
    }
}
