﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarClassLibrary
{
    public class StandardMessages
    {
        public static string DisplayMainMenu()
        {
            return "1. Create Car\n2. Acclerate\n3. Brake\n4. Exit";
        }

        public static string ShowChoiceError()
        {
            return "Not a valid choice...";
        }
        public static string AskForYear()
        {
            return "What is the year of the car?... ";
        }

        public static  string AskForMake()
        {
            return "What is the make of the car?... ";
        }

        public static string DisplaySpeed(Car inputCar)
        {
            return ($"The car is going {inputCar.Speed} MPH.");
        }
    }
}
