﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarClassLibrary;

namespace ConsoleUI
{
    public class BuildCar
    {
        public static void BuildACar(Car inputCar)
        {
            Console.WriteLine(StandardMessages.AskForYear());
            inputCar.Year = Console.ReadLine();

            Console.WriteLine(StandardMessages.AskForMake());
            inputCar.Make = Console.ReadLine();
        }
    }
}
