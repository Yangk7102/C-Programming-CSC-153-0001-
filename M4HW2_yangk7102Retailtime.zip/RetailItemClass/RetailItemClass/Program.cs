﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailLib;
/**
* 4.10.2020
* CSC 153
* kabin yang
* makes a list of stuff / howmuch stuff and how much it cost.
*/

namespace ConsoleUI
{
    public class Program
    {
        static void Main(string[] args)
        {
            string input;
            string input1, input2, input3;

            bool loop = false; // for the loop
            int output; // parsing the input into output to get a int value
            do
            {
                // asks for the amount of products
                Console.WriteLine(StandardMsg.HowManyInputs());

                // inputs 
                input = Console.ReadLine();

                if (int.TryParse(input, out output)) //parseing thing
                {
                    loop = true;
                }
                else
                {
                    Console.WriteLine(StandardMsg.InvalidInput());
                }

            } while (loop == false);
            
            // list
            Retail[] Retail2 = new Retail[output];
            List<Retail> items = new List<Retail>();

            // so you can enter as much times as items they have
            for (int i = 0; i < output; i++)
            {
                // ask for item dsc
                Console.WriteLine(StandardMsg.DescrptionMssg());
                // desc input
                input1 = Console.ReadLine();

                // ask for units
                Console.WriteLine(StandardMsg.UnitsOnHandMsg());
                // units input
                input2 = Console.ReadLine();

                // ask for price
                Console.WriteLine(StandardMsg.PriceMsg());
                // price input
                input3 = Console.ReadLine();

                items.Add(new Retail(input1, input2, input3));
            }

            foreach(var item in items)
            {
                Console.WriteLine($"{item.Desc}, {item.UnitOnHand}, {item.Price}");
            }

            Console.ReadLine();


        }
    }
}
