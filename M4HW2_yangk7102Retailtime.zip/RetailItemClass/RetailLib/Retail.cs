﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailLib
{
    public class Retail
    {
        // Fields
        private string _desc;
        private string _unitOnHand;
        private string _price;

        // Constructor
        // Defaults
        public Retail()
        {
            Desc = "";
            UnitOnHand = "";
            Price = "";
        }

        public Retail(string desc, string unitOnHand, string price)
        {
            Desc = desc;
            UnitOnHand = unitOnHand;
            Price = price;
        }

        // Full Property
        public string Desc
        {
            get
            {
                return _desc;
            }
            set
            {
                _desc = value;
            }
        }
        public string UnitOnHand
        {
            get
            {
                return _unitOnHand;
            }
            set
            {
                _unitOnHand = value;
            }
        }
        public string Price
        {
            get
            {
                return _price;
            }
            set
            {
                _price = value;
            }
        }

        // Methods?
    }
}
