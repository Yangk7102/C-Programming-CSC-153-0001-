﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailLib
{
    public class StandardMsg
    {
        public static string DescrptionMssg()
        {
            return "Enter the Descrption: ";
        }

        public static string UnitsOnHandMsg()
        {
            return "How many units do you have on hand: ";
        }

        public static string PriceMsg()
        {
            return "How much is the retail price: ";
        }

        public static string HowManyInputs()
        {
            return "How many items do you have: ";
        }

        public static string InvalidInput()
        {
            return "Invalid input... ";
        }
    }
}
