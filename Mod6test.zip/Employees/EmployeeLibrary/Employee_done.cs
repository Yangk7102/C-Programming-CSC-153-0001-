﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Employee
    {
        // Fields
        private string _name;
        private string _phoneNumber;
        private string _worker;
        private int _pay;
        private int _age;

        // Constructers
        public Employee()
        {
            Name = "No Name";
            PhoneNumber = "No Phone";
            Age = 0;
            Pay = 8;
        }

        public Employee(string worker)
        {
            _worker = worker;
        }
        public Employee(int pay)
        {
            _pay = pay;
        }

        public Employee(string name, string phone, int age)
        {
            Name = name;
            PhoneNumber = phone;
            Age = age;
        }
        // Properties
        public string Worker
        {
            get { return _worker; }
            set { _worker = value; }
        }

        public int Pay
        {
            get { return _pay; }
            set { _pay = value; }
        }
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public string PhoneNumber
        {
            get
            {
                return _phoneNumber;
            }
            set
            {
                _phoneNumber = value;
            }
        }

        public int Age
        {
            get
            {
                return _age;
            }
            set
            {
                _age = value;
            }
        }

        // Methods
        public virtual string MakeEmail()
        {
            return Name + "@worker.com";
        }

        public virtual int EmployeePay()
        {
            return 5;
        }
    }
}
