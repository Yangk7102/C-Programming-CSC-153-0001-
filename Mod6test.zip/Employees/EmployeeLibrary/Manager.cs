﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Manager : Employee
    {
        // feilds
        private string _promo;

        // constructor
        public Manager(string promo) : base("Manager")//, pay)
        {

        }
        // name prop
        public string Promo
        {
            get { return _promo; }
            set { _promo = value; }
        }

        public override string MakeEmail()
        {
            return Name + "@Manager.com";
        }

        public override int EmployeePay()
        {
            return base.EmployeePay() * 5;
        }

    }
}
