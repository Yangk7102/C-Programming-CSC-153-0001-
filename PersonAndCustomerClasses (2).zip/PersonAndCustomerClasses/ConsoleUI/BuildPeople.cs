﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Personlib;

namespace ConsoleUI
{
    class BuildPeople
    {
        public static void BuildPersonName(Person newPerson)
        {
            Console.WriteLine(StandardMsg.NameInputs()); //inptus
            newPerson.Name = Console.ReadLine();
        }
        public static void PersonPhone(Person newPerson)
        {
            Console.WriteLine(StandardMsg.PhoneInputs());
            newPerson.PhoneNumber = Console.ReadLine();
        }
        public static void PersonAddress(Person newPerson)
        {
            Console.WriteLine(StandardMsg.Addressinputs());
            newPerson.Address = Console.ReadLine();
        }
        public static void AmountSpent(Person newPerson)
        {
            Console.WriteLine(StandardMsg.MoneyInput());
            newPerson. = 1500;
        }
        public static void MailList(Person newPerson)
        {
            Console.WriteLine(StandardMsg.MailList());
            string input = Console.ReadLine();
            bool loop = true;
            do {
                if (input.ToLower() == "y")
                {
                    newPerson.MailList = true;
                    loop = false;
                }
                    
                else if (input.ToLower() == "n")
                {
                    newPerson.MailList = false;
                    loop = false;
                }

                else
                {
                    Console.WriteLine(StandardMsg.YesNoError());
                }
            } while (loop == true);

        }
    }

}
