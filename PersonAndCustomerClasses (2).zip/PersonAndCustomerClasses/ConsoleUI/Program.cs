﻿using Personlib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Person newPerson = new Person();
            BuildPeople.BuildPersonName(newPerson);

            BuildPeople.PersonPhone(newPerson);

            BuildPeople.PersonAddress(newPerson);

            BuildPeople.MailList(newPerson);

            BuildPeople.AmountSpent(newPerson);

            Console.WriteLine(StandardMsg.DisplayInfo(newPerson ));

            Console.WriteLine(StandardMsg.DiscountOutput(newPerson));

            
            Console.ReadLine();

        }
    }
}
