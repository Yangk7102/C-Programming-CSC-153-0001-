﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Personlib
{
    public class Person : ICustomer
    {
        // Fields
        private string _name;
        private string _address;
        private string _phoneNumber;
        private int _money;

        // Constructers
        // Default
        public Person()
        {
            Name = "";
            Address = "";
            PhoneNumber = "";
            bool Customer = new bool();
            int Discount;
            Money = 0;
        }

        // Custom
        public Person(string name, string address, string phoneNumber,int money)
        {
            Name = name;
            Address = address;
            PhoneNumber = phoneNumber;
            Money = money;
        }


        // Full Properties
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public string Address
        {
            get
            {
                return _address;
            }
            set
            {
                _address = value;
            }
        }

        public string PhoneNumber
        {
            get
            {
                return _phoneNumber;
            }
            set
            {
                _phoneNumber = value;
            }
        }

        public bool MailList { get; set; }
        public int Money { get; set; }
    }
}
