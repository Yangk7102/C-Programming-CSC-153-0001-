﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Personlib
{
    public class PreferredCustomer : Person
    {
        private int _spent;
        private int _discount;

        PreferredCustomer()
        {
            Discount = 0;
            Money = 0;
        }
        PreferredCustomer(int spent,int discount)
        {
            Discount = discount;
            Money = spent;
        }
        public int Spent { get; set; }
        public int Discount { get; set; }
        // methofs

        public int Discountlvl(int money)
        {
            int lvl;
            if (money < 500)
            {
                lvl = 0;
            }
            else if (money < 1000)
            {
                lvl = 5;
            }
            else if (money < 1500)
            {
                lvl = 6;
            }
            else if (money < 2000)
            {
                lvl = 7;
            }
            else
            {
                lvl = 10;
            }
            return lvl;
        }
    }
}
