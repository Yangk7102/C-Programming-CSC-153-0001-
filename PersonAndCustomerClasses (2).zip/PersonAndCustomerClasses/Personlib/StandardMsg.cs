﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Personlib
{
    public class StandardMsg
    {
        public static string NameInputs()
        {
            return "Enter Name: ";
        }
        public static string PhoneInputs()
        {
             return "Enter Phone Number: ";
        }
        public static string Addressinputs()
        {
            return "Enter Address: ";
        }

        public static string MailList()
        {
            return "Do you want to be in the mailing list?(y/n)";
        }
        public static string YesNoError()
        {
            return "Enter a y or n please.";
        }
        public static string DisplayInfo(Person newPerson)
        {
            return $"Name: {newPerson.Name} \nPhone Number: {newPerson.PhoneNumber}" +
                $"\nAddress: {newPerson.Address} \nMail List: {newPerson.MailList}";
        }
        public static string MoneyInput()
        {
            return "Enter the amount of money spent: ";
        }
        public static string DiscountOutput(Person newPerson)
        {
            return $"Discounted amount is: %{newPerson.}";
        }
    }
}
