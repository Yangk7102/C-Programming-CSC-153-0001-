﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**

* 2/15/2020

* CSC 153

* kabin yang
Modify the Main Menu to the following:

    Display Rooms
    Display Weapon
    Display Potion
    Display Treasure
    Display Items
    Display Mobs
    Exit

Build a program that has 4 arrays.

    Room – 5 Rooms (name of Rooms)
    Weapon – 4 Weapons (name of Weapons)
    Potion – 2 Potions (name of Potions)
    Treasure – 3 Treasures (name of Treasures)

 

Also in this program it should have 2 list.

    Item – 4 Items (name of Items)
    Mob – 5 Mobs (name of Mob)
*/

namespace ConsoleApp1
{
    class Program
    {

        static void Main(string[] args)
        {
            string input;
            bool exit = false;

            //const int SIZE = 5;

            int index;
            string[] roomNames = new string[5] 
                {"Village", "Cave", "Guild", "Knight's keep", "Capitol City" };
            string[] weaponNames = new string[4]
                {"Club", "Broken Sword", "Dagger", "Wand"};
            string[] potionNames = new string[2]
                {"Health", "Mana"};
            string[] treasureNames = new string[3]
                {"Hero's sword", "Sage's Staff", "Gold"};
            List<string> itemList = new List<string>(4);
            List<string> mobList = new List<string>(5);

            //string[] itemList[] = { "rock", "bottle", "herbs", "torch" };
            itemList.Add("Rock");
            itemList.Add("Bottle");
            itemList.Add("Herbs");
            itemList.Add("Torch");

            mobList.Add("Villager");
            mobList.Add("Gaurd");
            mobList.Add("Knight");
            mobList.Add("Adventurer");
            mobList.Add("Mage");

            Console.WriteLine("----Main Menu----\n");

            Console.WriteLine("1. Rooms ");
            Console.WriteLine("2. Weapons");
            Console.WriteLine("3. Potions");
            Console.WriteLine("4. Treasures");
            Console.WriteLine("5. Items ");
            Console.WriteLine("6. Mobs");
            Console.WriteLine("7. Exit");
            Console.Write("-->");
            do
            {

                input = Console.ReadLine();
                Console.WriteLine("");

                //Switch to direct to proper process
                switch (input)
                {
                    case "1":
                        Console.WriteLine("\n---Rooms---\n");
                        Console.WriteLine("You're in your Cave.\n");
                        index = 2;
                        Console.WriteLine("Where do you want to go North or South?\nType exit it exit.");
                        
                        int choice;
                        choice = 3;
                        do {
                            input = Console.ReadLine();
                            if (input.ToLower() == "north")
                            {
                                index += 1;
                                if (index == 5)
                                {
                                    index = 0;
                                }

                                Console.WriteLine("\nYou are at the " + roomNames[index] + "\nWhere next?\n");

                            }
                            else if (input.ToLower() == "south")
                            {
                                index = index - 1;
                                if(index == -1)
                                {
                                    index = 4;
                                }
                                Console.WriteLine("\nYou are at the " + roomNames[index] + "\nWhere next?\n");

                            }
                            else if (input.ToLower() == "exit")
                            {
                                choice = 2;
                            }
                            else
                            {
                                Console.WriteLine("\nEnter north or south please.");
                            }
                        } while (choice == 3);
                        Console.WriteLine("");
                        break;
                    case "2":
                        //todo
                        Console.WriteLine("\n---Weapons---\n");
                        for (int x = 0; x < 4; x++)
                        {
                            Array.Sort(weaponNames);
                            Console.WriteLine($" Weapon name - {weaponNames[x]}");
                            Console.WriteLine("");
                        }
                        Console.WriteLine("");
                        break;

                    case "3":
                        Console.WriteLine("\n---Potions---\n");
                        for (int x = 0; x < 2; x++)
                        {
                            Console.WriteLine($" Potion name - {potionNames[x]}");
                            Console.WriteLine("");
                        }
                        Console.WriteLine("");

                        break;

                    case "4":
                        Console.WriteLine("\n---Treasures---\n");
                        for (int x = 0; x < 3; x++)
                        {
                            Console.WriteLine($" Treasure name - {treasureNames[x]}");
                            Console.WriteLine("");
                        }
                        Console.WriteLine("");
                        break;

                    case "5":
                        Console.WriteLine("\n---Items---\n");
                        for  (index = 0; index < itemList.Count; index++)
                        {
                            Console.WriteLine($"Items - {itemList[index]}");
                            Console.WriteLine("");
                        }
                        Console.WriteLine("");
                        break;

                    case "6":
                        Console.WriteLine("\n---Mobs---\n");
                        for (index = 0; index < mobList.Count; index++)
                        {
                            Console.WriteLine($"Mobs - {mobList[index]}");
                            Console.WriteLine("");
                        }
                        Console.WriteLine("");
                        break;

                    case "7":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Wrong input");
                        break;
                }

            } while (exit == false);
        }
    }
}
