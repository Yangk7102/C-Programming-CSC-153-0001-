﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 * DATE
 * CSC 153
 * name
 * desc
 */
namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            // create input car for user inputs and sentry for loop
            string input;
            bool exit = false;

            const int SIZE = 5;

            int nameIndex = 0, phoneIndex = 0;
            string[] employeeNames = new string[SIZE];
            string[] employeePhone = new string[SIZE];
            List<int> employeeAge = new List<int>();

            do
            {
                Console.WriteLine("1. Enter employee's name. ");
                Console.WriteLine("2. Enter employee's phone number. ");
                Console.WriteLine("3. Enter employee's age. ");
                Console.WriteLine("4. Display employee information. ");
                Console.WriteLine("5. Display average age of employees. ");
                Console.WriteLine("6. Exit");
                Console.Write("-->");
                input = Console.ReadLine();
                Console.WriteLine("");

                //Switch to direct to proper process
                switch (input)
                {
                    case "1":
                        //todo enter emp names
                        Console.Write("Enter employee's names: ");
                        input = Console.ReadLine();
                        Console.WriteLine("");
                        employeeNames[nameIndex] = input;
                        nameIndex++;
                        Console.WriteLine("");

                        break;
                    case "2":
                        //todo
                        Console.Write("Enter employee's phone number: ");
                        input = Console.ReadLine();
                        Console.WriteLine("");
                        employeePhone[phoneIndex] = input;
                        nameIndex++;
                        Console.WriteLine("");
                        break;
                    case "3":
                        //todo
                        int number = 0;
                        Console.Write("Enter employees age: ");
                        input = Console.ReadLine();
                        Console.WriteLine("");

                        if (int.TryParse(input, out number))
                        {
                            employeeAge.Add(number);
                        }
                        else
                        {
                            Console.WriteLine("Not a valid number...");
                            Console.WriteLine("");
                        }
                        break;
                    case "4":
                        for(int index = 0; index < employeeAge.Count; index++)
                        {
                            Console.WriteLine($"Employee name - {employeeNames[index]}");
                            Console.WriteLine($"Employee Phone - {employeePhone[index]}");
                            Console.WriteLine($"Employee Age - {employeeAge[index]}");
                            Console.WriteLine("");
                            phoneIndex++;
                        }
                        break;
                    case "5":
                        Console.WriteLine(employeeAge.Average());
                        Console.WriteLine("");
                        break;
                    case "6":
                        exit = true;
                        break;
                    default:
                        //todo
                        break;
                }

            } while (exit == false);
        }
    }
}
