﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLib
{
    public class StandardMessages
    {
        public static string MainMenu()
        {
            return "----Main Menu----\n1. Actions \n2. Weapons\n3. Potions \n4. Treasures\n" +
            "5. Items \n6. Mobs\n7. Exit\n-->";
        }
        public static string ActionMenu()
        {
            return "\n---Actions---\n1. Move\n2. Attack\n3. Exit\n... ";
        }

        public static string AttackMenu()
        {
            return "1) attack \n2) run \n 3) exit";
        }

        public static string InvalidInput()
        {
            return "invalid entry ...";
        }

        public static string UsernameInput()
        {
            return "Enter your Username: ";
        }

        public static string PasswordInput()
        {
            return "Enter your Password: ";
        }
        public static string WeakPasword()
        {
            return "Pasword must include a special character...";
        }
        public static string ChooseClass()
        {
            return "Pick a class\n1) warrior\n2) mage \n3) tbd...";
        }
        public static string ChooseRace()
        {
            return "Pick a race\n1) human\n2) mob \n3) tbd...";
        }
    }
}
