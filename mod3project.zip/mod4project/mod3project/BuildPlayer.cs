﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GameLib;

namespace mod3project
{
    public class BuildPlayer
    {
        public static void BuildAPlayer()
        {
            string input;
            Player Account = new Player();
            Console.WriteLine(StandardMessages.UsernameInput());// enter user name
            Account.Username = Console.ReadLine();

            Console.WriteLine(StandardMessages.PasswordInput());
            bool loop = true;
            do
            {
                input = Console.ReadLine();
                string specialChar = @"\|!#$%&/()=?»«@£§€{}.-;'<>_,";
                foreach (var item in specialChar)
                {
                    if (input.Contains(item))
                    {
                        Account.Password = Console.ReadLine();
                        loop = false;
                    }

                    else
                    {
                        Console.WriteLine(GameLib.StandardMessages.WeakPasword());
                    }

                }
            } while (loop == true);
            loop = true;

            // building the charevter now
            Console.WriteLine(GameLib.StandardMessages.ChooseClass());

            do
            {
                switch (Console.ReadLine())
                {
                    case "1":
                        Account.Classes = "Warrior";
                        loop = false;
                        break;
                    case "2":
                        Account.Classes = "Mage";
                        loop = false;
                        break;
                    case "3":
                        Account.Classes = "tbd";
                        loop = false;
                        break;
                    default:
                        Console.WriteLine(GameLib.StandardMessages.InvalidInput());
                        break;


                }

            } while (loop == true);

            loop = true;

            // building the charevter now
            Console.WriteLine(GameLib.StandardMessages.ChooseRace());

            do
            {
                switch (Console.ReadLine())
                {
                    case "1":
                        Account.Race = "Human";
                        loop = false;
                        break;
                    case "2":
                        Account.Race = "Mob";
                        loop = false;
                        break;
                    case "3":
                        Account.Race = "tbd";
                        loop = false;
                        break;
                    default:
                        Console.WriteLine(GameLib.StandardMessages.InvalidInput());
                        break;


                }

            } while (loop == true);
        }
    }
}
