﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mod3project
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            bool exit = false;
            int hp, mana;
            hp = 20;
            mana = 20;
            //const int SIZE = 5;

            

            int index;
            string[] roomNames = new string[5]
                {"Village", "Cave", "Guild", "Knight's keep", "Capitol City" };
            string[] weaponNames = new string[4]
                {"Club", "Broken Sword", "Dagger", "Wand"};
            string[] potionNames = new string[2]
                {"Health", "Mana"};
            string[] treasureNames = new string[3]
                {"Hero's sword", "Sage's Staff", "Gold"};
            List<string> itemList = new List<string>(4);
            List<string> mobList = new List<string>(5);

            //string[] itemList[] = { "rock", "bottle", "herbs", "torch" };
            itemList.Add("Rock");
            itemList.Add("Bottle");
            itemList.Add("Herbs");
            itemList.Add("Torch");

            mobList.Add("Villager");
            mobList.Add("Gaurd");
            mobList.Add("Knight");
            mobList.Add("Adventurer");
            mobList.Add("Mage");

            BuildPlayer.BuildAPlayer(); // to make a player

            // for the room array
            int RoomIndex;
            RoomIndex = 3;
            Console.WriteLine(GameLib.StandardMessages.MainMenu());

            do
            {

                input = Console.ReadLine();
                Console.WriteLine("");

                //Switch to direct to proper process
                switch (input)
                {
                    case "1":
                        RoomIndex = ActionMenu(input, ref roomNames, ref RoomIndex, ref hp, ref mana);
                        
                        break;
                    case "2":
                        
                        Console.WriteLine("\n---Weapons---\n");
                        for (int x = 0; x < 4; x++)
                        {
                            Array.Sort(weaponNames);
                            Console.WriteLine($" Weapon name - {weaponNames[x]}");
                            Console.WriteLine("");
                        }
                        Console.WriteLine("");
                        break;

                    case "3":
                        Console.WriteLine("\n---Potions---\n");
                        for (int x = 0; x < 2; x++)
                        {
                            Console.WriteLine($" Potion name - {potionNames[x]}");
                            Console.WriteLine("");
                        }
                        Console.WriteLine("");

                        break;

                    case "4":
                        Console.WriteLine("\n---Treasures---\n");
                        for (int x = 0; x < 3; x++)
                        {
                            Console.WriteLine($" Treasure name - {treasureNames[x]}");
                            Console.WriteLine("");
                        }
                        Console.WriteLine("");
                        break;

                    case "5":
                        Console.WriteLine("\n---Items---\n");
                        for (index = 0; index < itemList.Count; index++)
                        {
                            Console.WriteLine($"Items - {itemList[index]}");
                            Console.WriteLine("");
                        }
                        Console.WriteLine("");
                        break;

                    case "6":
                        Console.WriteLine("\n---Mobs---\n");
                        for (index = 0; index < mobList.Count; index++)
                        {
                            Console.WriteLine($"Mobs - {mobList[index]}");
                            Console.WriteLine("");
                        }
                        Console.WriteLine("");
                        break;

                    case "7":
                        exit = true;
                        break;
                    default:
                        GameLib.StandardMessages.InvalidInput();
                        break;
                }

            } while (exit == false);
            Console.WriteLine("main menu exit");
        }

        private static int ActionMenu(string input, ref string[] roomNames, ref int RoomIndex, ref int hp, ref int mana)
        {
            bool choice = true;
            GameLib.StandardMessages.ActionMenu();           
            do
            {
                input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                        Console.WriteLine("Where do you want to move?(north or south)");
                        ActionMove(input, ref roomNames, ref RoomIndex);
                        break;
                    case "2":
                        AttackMenu(ref hp, ref mana);

                        break;
                    case "3":
                        Console.WriteLine("Going to main menu.");
                        choice = false;
                        break;
                    default:
                        GameLib.StandardMessages.InvalidInput();
                        break;
                }

                
            }while(choice == true);
            Console.WriteLine("action menu exit");
            return RoomIndex;
        }

        private static void AttackMenu(ref int hp, ref int mana)
        {
            bool choice = true;
            GameLib.StandardMessages.AttackMenu();
           
            do
            {
                string input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                        DoAttackCalc(ref hp, ref mana);
                        
                        break;
                    case "2":
                        DoRunRng();
                        break;
                    case "3":
                        Console.WriteLine("Going back to menu.");
                        choice = false;
                        break;
                    default:
                        GameLib.StandardMessages.InvalidInput();
                        break;
                }

            } while (choice == true);
            Console.WriteLine("exit att menu");
        }

        private static void DoRunRng()
        {
            Console.WriteLine("You chose to run (coward!).");
            Random random = new Random();
            int num = random.Next(0, 6);
            if (num <= 3)
            {
                Console.WriteLine("You Ran away safely");
            }
            else
            {
                Console.WriteLine("Fight you coward!");
            }
        }

        private static void DoAttackCalc(ref int hp, ref int mana)
        {
            Console.WriteLine("You chose to attack.");
            Random random = new Random();
            int num = random.Next(0, 6);
            hp -= num;
            Console.WriteLine($"You took {num} amount of damage and you have {hp} left.");
        }

        private static int ActionMove(string input, ref string[] roomNames, ref int RoomIndex)
        {
            bool choice = true;
            Console.WriteLine("eat 2 duckss");
            do
            {
                input = Console.ReadLine();
                switch (input.ToLower())
                {
                    case "north":
                        RoomIndex += 1;
                        if (RoomIndex == 5)
                        {
                            RoomIndex = 0;
                        }

                        Console.WriteLine("\nYou are at the " + roomNames[RoomIndex] + "\nWhere next?\n");
                        break;

                    case "south":
                        RoomIndex = RoomIndex - 1;
                        if (RoomIndex == -1)
                        {
                            RoomIndex = 4;
                        }
                        Console.WriteLine("\nYou are at the " + roomNames[RoomIndex] + "\nWhere next?\n");
                        break;

                    case "exit":
                        choice = false;
                        Console.WriteLine("bool = " + choice);
                        break;

                    default:
                        Console.WriteLine("if one more things i breaks i swear to god.");
                        break;
                }
                
            } while (choice == true);
            Console.WriteLine("room exit");
            return RoomIndex;
        }
            
    }
}
