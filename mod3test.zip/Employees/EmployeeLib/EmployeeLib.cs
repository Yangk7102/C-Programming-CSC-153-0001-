﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLib
{
    public class StandardMessag
    {
        public static string Menu()
        {
            Console.WriteLine("1. Enter employee's name. ");
            Console.WriteLine("2. Enter employee's phone number. ");
            Console.WriteLine("3. Enter employee's age. ");
            Console.WriteLine("4. Display employee information. ");
            Console.WriteLine("5. Display average age of employees. ");
            Console.WriteLine("6. Exit");
            Console.Write("-->");
            return "";
        }
        //did i do this for nothing?
        //   |
        //   |
        //\     /
        // \   /
        //  \ /
        public static string NameMenu()
        {

            Console.Write("Enter employee's names: ");
            string input = Console.ReadLine();
            Console.WriteLine("");
            return input;
        }

        public static string NumberMenu()
        {
            Console.WriteLine("");
            Console.Write("Enter employee's phone number: ");
            string input = Console.ReadLine();
            Console.WriteLine("");
            return input;
        }

        public static void DefaultPrints()
        {
            Console.WriteLine("Enter a number please.");
        }
    }
}
