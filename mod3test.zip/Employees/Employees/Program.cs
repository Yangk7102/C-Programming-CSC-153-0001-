﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
 * kabin yang
 * march 6 2020
 * made methods for the employee program
 * 
 */
namespace Employees
{
    class Program
    {
        static void Main(string[] args)
        {
            // create input car for user inputs and sentry for loop
            string input;
            bool exit = false;

            const int SIZE = 5;

            int nameIndex = 0, phoneIndex = 0;
            string[] employeeNames = new string[SIZE];
            string[] employeePhone = new string[SIZE];
            List<int> employeeAge = new List<int>();

            do                                          //made a menu that loops
            {
                EmployeeLib.StandardMessag.Menu();      //menu hidden here
                input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        employeeNames = EnterName(employeeNames, ref nameIndex);        //goes the the name makeing array method
                        break;
                    case "2":
                        employeePhone = EnterNumber(employeePhone, ref phoneIndex);     //goes to the number making array method
                        break;
                    case "3":
                        employeeAge  = EnterAge(employeeAge);                           // goes to the employee age list maker
                        break;
                    case "4":
                        DisplayEmployee(employeeNames, employeePhone, employeeAge);     //goes to the list/array display commands
                        break;
                    case "5":
                        DisplayAverageAge(employeeAge);                                 //averages the ages
                        break;
                    case  "6":
                        exit = true;                                                    //closes the program
                        break;
                    default:
                        EmployeeLib.StandardMessag.DefaultPrints();                     // shows error message
                        break;


                }
            } while (exit == false);
        }

        public static string[] EnterName(string[] employeeNames, ref int nameIndex)     // adds names to a array declared uptop
        {
            string input;       
            input = EmployeeLib.StandardMessag.NameMenu();
            employeeNames[nameIndex] = input;
            nameIndex++;
            return employeeNames;
        }

        public static string[] EnterNumber(string[] employeePhone, ref int phoneIndex) // adds numbers to a array declared uptop
        {
            string input;
            input = EmployeeLib.StandardMessag.NumberMenu();
            employeePhone[phoneIndex] = input;
            phoneIndex++;
            return employeePhone;
        }

        public static List<int> EnterAge(List<int> employeeAge)                         // adds ages to a list
        {
            Console.Write("Enter employees age: ");
            string input = Console.ReadLine();
            Console.WriteLine("");
            if (int.TryParse(input, out int number))                                    // trys to pars the number inputed
            {
                employeeAge.Add(number);
            }
            else
            {
                Console.WriteLine("Not a valid number...");
                Console.WriteLine("");
            }
            return employeeAge;
        }

        public static void DisplayEmployee(string[] employeeNames, string[] employeePhone, List<int> employeeAge) // alots of wrtielines
        {
            for(int index = 0; index < employeeAge.Count; index++)
                        {
                Console.WriteLine($"Employee name - {employeeNames[index]}");
                Console.WriteLine($"Employee Phone - {employeePhone[index]}");
                Console.WriteLine($"Employee Age - {employeeAge[index]}");
                Console.WriteLine("");
            }
        }

        public static void DisplayAverageAge(List<int> employeeAge)                                 //age averager
        {
            Console.WriteLine(employeeAge.Average());
            Console.WriteLine("");
        }
    }
}
