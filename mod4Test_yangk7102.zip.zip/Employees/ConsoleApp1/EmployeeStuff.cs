﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLib;

namespace ConsoleApp1
{
    class EmployeeStuff
    {
        public static void BuildEmployeeNames(Employees inputNames)
        {
            EmployeeLib.StandardMessages.EnterNames();
            inputNames.Name = Console.ReadLine();
            EmployeeLib.StandardMessages.Spacer();
            EmployeeLib.StandardMessages.Spacer();
        }

        public static void BuildEmployeePhones(Employees inputPhones)
        {
            EmployeeLib.StandardMessages.EnterPhoneNumber();
            inputPhones.Phone = Console.ReadLine();
            EmployeeLib.StandardMessages.Spacer();
            EmployeeLib.StandardMessages.Spacer();
        }

        public static int EmployeeAge(Employees inputAge)
        {
            string input;
            int number;
            EmployeeLib.StandardMessages.EnterAge();
            input = Console.ReadLine();
            EmployeeLib.StandardMessages.Spacer();

            if (int.TryParse(input, out number))
            {
                number = inputAge;

            }
            else
            {
                EmployeeLib.StandardMessages.ErrorMessage();
                EmployeeLib.StandardMessages.Spacer();
            }
            return 2;
        }
    }
}
