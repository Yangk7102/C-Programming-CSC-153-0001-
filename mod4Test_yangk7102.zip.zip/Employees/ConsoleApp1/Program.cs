﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1;
using EmployeeLib;

/**
 * DATE
 * CSC 153
 * name
 * desc
 */
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            // create input car for user inputs and sentry for loop
            string input;
            bool exit = false;

            const int SIZE = 5;

            int nameIndex = 0, phoneIndex = 0;
            string[] employeeNames = new string[SIZE];
            string[] employeePhone = new string[SIZE];
            List<int> employeeAge = new List<int>();

            Employees inputNames = new Employees();
            Employees inputPhones = new Employees();


            do
            {
                EmployeeLib.StandardMessages.Menu();
                input = Console.ReadLine();
                EmployeeLib.StandardMessages.Spacer();

                //Switch to direct to proper process
                switch (input)
                {
                    case "1":
                        // input
                        /**
                        EmployeeLib.StandardMessages.EnterNames();
                        input = Console.ReadLine();
                        EmployeeLib.StandardMessages.Spacer();
                        employeeNames[nameIndex] = input;
                        nameIndex++;
                        EmployeeLib.StandardMessages.Spacer();
                        */
                        EmployeeStuff.BuildEmployeeNames(inputNames);
                        break;
                    case "2":
                        //input
                        /**
                        EmployeeLib.StandardMessages.EnterPhoneNumber();
                        input = Console.ReadLine();
                        EmployeeLib.StandardMessages.Spacer();
                        employeePhone[phoneIndex] = input;
                        nameIndex++;
                        EmployeeLib.StandardMessages.Spacer();
                        */
                        EmployeeStuff.BuildEmployeePhones(inputPhones);
                        phoneIndex++; 
                        break;

                    case "3":
                        //input
                        EmployeeStuff.EmployeeAge(inputAge);
                        /**int number = 0;
                        EmployeeLib.StandardMessages.EnterAge();
                        input = Console.ReadLine();
                        EmployeeLib.StandardMessages.Spacer();

                        if (int.TryParse(input, out number))
                        {
                            employeeAge.Add(number);
                        }
                        else
                        {
                            EmployeeLib.StandardMessages.ErrorMessage();
                            EmployeeLib.StandardMessages.Spacer();
                        }
                        */
                        break;
                    case "4":
                        for(int index = 0; index < employeeAge.Count; index++)
                        {
                            EmployeeLib.StandardMessages.InfoOutput(employeeNames,employeePhone, employeeAge,
                                                                                ref index);
                            EmployeeLib.StandardMessages.Spacer();
                            phoneIndex++;
                        }
                        break;
                    case "5":
                        Console.WriteLine(employeeAge.Average());
                        EmployeeLib.StandardMessages.Spacer();
                        break;
                    case "6":
                        exit = true;
                        break;
                    default:
                        EmployeeLib.StandardMessages.ErrorMessage();
                        break;
                }

            } while (exit == false);
        }
    }
}
