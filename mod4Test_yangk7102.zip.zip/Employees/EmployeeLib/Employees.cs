﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLib
{
    public class Employees
    {
        // fields
        private string _name;
        private string _phone;
        private int _age;

        // constructor
        public Employees()
        {
            Name = "";
            Phone = "";
            Age = 0;
        }

        public Employees(string name, string phone)
        {
            Name = name;
            Phone = phone;
            Age = 0;
        }

        // properties
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public string Phone
        {
            get
            {
                return _phone;
            }
            set
            {
                _phone = value;
            }
        }

        public int Age
        {
            get
            {
                return _age;
            }
            set
            {
                _age = value;
            }
        }

        // methods

        public void AddAge()
        {
            Age +=1;
        }






    }
}
