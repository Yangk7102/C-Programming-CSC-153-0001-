﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLib
{
    public class StandardMessages
    {
        public static void Menu()
        {
            Console.WriteLine("1. Enter employee's name. ");
            Console.WriteLine("2. Enter employee's phone number. ");
            Console.WriteLine("3. Enter employee's age. ");
            Console.WriteLine("4. Display employee information. ");
            Console.WriteLine("5. Display average age of employees. ");
            Console.WriteLine("6. Exit");
            Console.Write("-->");
        }

        public static void ErrorMessage()
        {
            Console.WriteLine("Invalid input...");
        }

        public static void Spacer()
        {
            Console.WriteLine("");
        }

        public static void InfoOutput(string[] employeeNames, string[] employeePhone,
                                                    List<int> employeeAge, ref int index)
        {
            Console.WriteLine($"Employee name - {employeeNames[index]}");
            Console.WriteLine($"Employee Phone - {employeePhone[index]}");
            Console.WriteLine($"Employee Age - {employeeAge[index]}");
        }

        public static void EnterNames()
            {
                Console.Write("Enter employee's names: ");
            }

        public static void EnterPhoneNumber()
        {
            Console.Write("Enter employee's phone number: ");
        }

        public static void EnterAge()
        {
            Console.Write("Enter employees age: ");
        }
    }
}
