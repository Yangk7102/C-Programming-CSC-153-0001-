﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLib
{
    public class GameRooms
    {
        //feilds
        private string _roomName;
        private string _roomDesc;
        private string _exit;

        // con

        public GameRooms()
        {
            RoomNames = "";
            RoomDesc = "";
            Exit = "";
        }
        public GameRooms(String roomNames,String roomDesc,String exit)
        {
            RoomNames = roomNames;
            RoomDesc = roomDesc;
            Exit = exit;
        }

        public string RoomNames
        {
            get
            {
                return _roomName;
            }
            set
            {
                _roomName = value;
            }
        }
        public string RoomDesc
        {
            get
            {
                return _roomDesc;
            }
            set
            {
                _roomDesc = value;
            }
        }
        public string Exit
        {
            get
            {
                return _exit;
            }
            set
            {
                _exit = value;
            }
        }
    }
}
