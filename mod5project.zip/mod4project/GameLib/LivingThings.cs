﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLib
{
    public class LivingThings
    {
        //feilds
        private int _hp;
        private int _mp;
        private int _maxDamage;
        private int _minDamage;

        public LivingThings()
        {
            Hp = 20;
            Mp = 10;
            MaxDamage = 5;
            MinDamage = 1;
        }

        public LivingThings(int mp,int hp,int maxDamage,int minDamage)
        {
            Mp = mp;
            Hp = hp;
            MaxDamage = maxDamage;
            MinDamage = minDamage;
        }
        public int Mp { get; set; }
        public int Hp { get; set; }
        public int MaxDamage { get; set; }
        public int MinDamage { get; set; }
    }

}
