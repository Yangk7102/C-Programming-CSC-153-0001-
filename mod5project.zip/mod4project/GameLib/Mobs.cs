﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLib
{
    public class Mobs : LivingThings
    {
        private string _classes;
        private string _race;

        // constructor
        public Mobs()
        {
            Classes = "evil";
            Race = "human";
        }

        public Mobs(string classes, string race)
        {
            Classes = classes;
            Race = race;
        }

        // properties
       

        public string Classes
        {
            get
            {
                return _classes;
            }
            set
            {
                _classes = value;
            }
        }
        public string Race
        {
            get
            {
                return _race;
            }
            set
            {
                _race = value;
            }
        }
    }
}
