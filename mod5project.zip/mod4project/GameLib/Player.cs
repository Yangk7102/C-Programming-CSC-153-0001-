﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLib
{
    public class Player : LivingThings
    {
        // fields
        private string _username;
        private string _password;
        private string _classes;
        private string _race;

        // constructor
        public Player()
        {
            Username = "";
            Password = "";
        }

        public Player(string username, string password,string classes, string race)
        {
            Username = username;
            Password = password;
            Classes = classes;
            Race = race;
        }

        // properties
        public string Username
        {
            get
            {
                return _username;
            }
            set
            {
                _username = value;
            }
        }

        public string Password
        {
            get
            {
                return _password;
            }
            set
            {
                _password = value;
            }
        }

        public string Classes
        {
            get
            {
                return _classes;
            }
            set
            {
                _classes = value;
            }
        }
        public string Race
        {
            get
            {
                return _race;
            }
            set
            {
                _race = value;
            }
        }

        // Methods


    }
}
