﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameLib
{
    public class StandardMessages
    {
        public static void MainMenu()
        {
            Console.WriteLine("----Main Menu----\n");

            Console.WriteLine("1. Actions ");
            Console.WriteLine("2. Weapons");
            Console.WriteLine("3. Potions");
            Console.WriteLine("4. Treasures");
            Console.WriteLine("5. Items ");
            Console.WriteLine("6. Mobs");
            Console.WriteLine("7. Exit");
            Console.Write("-->");
        }
        public static void ActionMenu()
        {
            Console.WriteLine("\n---Actions---\n");
            Console.WriteLine("1. Move ");
            Console.WriteLine("2. Attack");
            Console.WriteLine("3. Exit");
            Console.Write("... ");
        }

        public static void AttackMenu()
        {
            Console.WriteLine("1) attack \n2) run \n 3) exit");
        }

        public static void InvalidInput()
        {
            Console.WriteLine("invalid entry ..."); 
        }
    }
}
